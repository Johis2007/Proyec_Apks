package com.example.conversionnumerica;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Actividad principal que gestiona la interfaz de usuario y el flujo de conversión.
 * Actúa como cliente de la jerarquía de conversores.
 *
 * @author Android Senior Developer
 * @version 1.0
 */
public class MainActivity extends AppCompatActivity {

    /** Campo de entrada para el número decimal. */
    private EditText etNumero;

    /** Campo de entrada/visualización para la base destino. */
    private EditText etBaseDestino;

    /** Selector de opciones predefinidas o personalizada. */
    private Spinner spinnerOpciones;

    /** Botón para ejecutar la conversión. */
    private Button btnConvertir;

    /** Etiqueta para mostrar el resultado. */
    private TextView tvResultado;

    /** Referencia polimórfica al conversor actual. */
    private ConversorBase conversor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de vistas
        initViews();

        // Configuración del Spinner
        setupSpinner();

        // Configuración del botón
        setupButtonListener();
    }

    /**
     * Inicializa las referencias a los componentes de la vista.
     */
    private void initViews() {
        etNumero = findViewById(R.id.et_numero);
        etBaseDestino = findViewById(R.id.et_base_destino);
        spinnerOpciones = findViewById(R.id.spinner_opciones);
        btnConvertir = findViewById(R.id.btn_convertir);
        tvResultado = findViewById(R.id.tv_resultado);
    }

    /**
     * Configura el adaptador y el listener para el Spinner de selección de base.
     */
    private void setupSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.bases_numericas,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOpciones.setAdapter(adapter);

        spinnerOpciones.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String seleccion = parent.getItemAtPosition(position).toString();
                manejarSeleccionSpinner(seleccion);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No se requiere acción
            }
        });
    }

    /**
     * Maneja la lógica de habilitación/deshabilitación del campo de base según la selección.
     *
     * @param seleccion Texto seleccionado en el Spinner.
     */
    private void manejarSeleccionSpinner(String seleccion) {
        if (seleccion.equals("Otra base")) {
            etBaseDestino.setEnabled(true);
            etBaseDestino.getText().clear();
            etBaseDestino.setHint("Ej: 5");
        } else {
            etBaseDestino.setEnabled(false);
            String baseValor = obtenerBaseDeSeleccion(seleccion);
            etBaseDestino.setText(baseValor);
        }
    }

    /**
     * Extrae el valor numérico de la base a partir del texto de selección.
     *
     * @param seleccion Texto del Spinner (ej. "Binario (2)").
     * @return Valor numérico de la base (ej. "2").
     */
    private String obtenerBaseDeSeleccion(String seleccion) {
        if (seleccion.contains("Binario")) return "2";
        if (seleccion.contains("Octal")) return "8";
        if (seleccion.contains("Hexadecimal")) return "16";
        if (seleccion.contains("Base 12")) return "12";
        return "";
    }

    /**
     * Configura el listener del botón de conversión.
     */
    private void setupButtonListener() {
        btnConvertir.setOnClickListener(v -> realizarConversion());
    }

    /**
     * Orquesta el proceso de conversión: validación, fábrica de conversor y visualización.
     */
    private void realizarConversion() {
        // Validación de entrada numérica
        String strNumero = etNumero.getText().toString().trim();
        if (strNumero.isEmpty()) {
            Toast.makeText(this, "Ingrese un número válido", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validación de base
        String strBase = etBaseDestino.getText().toString().trim();
        if (strBase.isEmpty()) {
            Toast.makeText(this, "Ingrese o seleccione una base", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            long numero = Long.parseLong(strNumero);
            int base = Integer.parseInt(strBase);

            // Uso del método fábrica
            conversor = crearConversor(numero, base);

            // Invocación polimórfica
            String resultado = conversor.convertir();
            String descripcion = conversor.obtenerDescripcion();

            tvResultado.setText(String.format("%s:\n%s", descripcion, resultado));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Error en el formato de los números", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Método fábrica que instancia la subclase de ConversorBase apropiada.
     * Si la base es 2, 8, 12 o 16, usa ConversorPredefinido.
     * De lo contrario, usa ConversorPersonalizado.
     *
     * @param numero Número a convertir.
     * @param base   Base destino.
     * @return Instancia de ConversorBase.
     */
    private ConversorBase crearConversor(long numero, int base) {
        // Determinamos si la base corresponde a una opción predefinida "fija"
        if (base == 2 || base == 8 || base == 12 || base == 16) {
            String nombreBase = obtenerNombreBase(base);
            return new ConversorPredefinido(numero, base, nombreBase);
        } else {
            return new ConversorPersonalizado(numero, base);
        }
    }

    /**
     * Obtiene el nombre legible para las bases predefinidas.
     *
     * @param base Valor de la base.
     * @return Nombre legible.
     */
    private String obtenerNombreBase(int base) {
        switch (base) {
            case 2: return "Binario";
            case 8: return "Octal";
            case 16: return "Hexadecimal";
            case 12: return "Base 12";
            default: return "Base " + base;
        }
    }
}