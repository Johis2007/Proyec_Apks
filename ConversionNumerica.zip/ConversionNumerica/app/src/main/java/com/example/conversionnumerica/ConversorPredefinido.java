package com.example.conversionnumerica;

/**
 * Clase que representa un conversor para bases predefinidas comunes (Binario, Octal, Hexadecimal, Base 12).
 * Hereda de {@link ConversorBase}.
 *
 * @author Android Senior Developer
 * @version 1.0
 */
public class ConversorPredefinido extends ConversorBase {

    /** Nombre descriptivo de la base numérica (ej. "Binario"). */
    private String nombreBase;

    /**
     * Constructor que inicializa el conversor predefinido.
     *
     * @param numero      Número a convertir.
     * @param base        Base destino.
     * @param nombreBase  Nombre legible de la base.
     */
    public ConversorPredefinido(long numero, int base, String nombreBase) {
        super(numero, base);
        this.nombreBase = nombreBase;
    }

    /**
     * Implementación concreta del método convertir.
     * Delega el cálculo al algoritmo de la clase padre.
     *
     * @return Resultado de la conversión.
     */
    @Override
    public String convertir() {
        return algoritmoConversion(this.numero, this.base);
    }

    /**
     * Sobrescribe el método para ofrecer una descripción más amigable usando el nombre de la base.
     *
     * @return Descripción personalizada (ej. "Conversión a Binario").
     */
    @Override
    public String obtenerDescripcion() {
        return "Conversión a " + this.nombreBase;
    }
}
