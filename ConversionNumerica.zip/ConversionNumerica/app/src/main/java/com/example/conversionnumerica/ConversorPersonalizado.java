package com.example.conversionnumerica;

/**
 * Clase que permite la conversión a bases numéricas personalizadas definidas por el usuario.
 * Valida que la base esté dentro del rango permitido (2-16).
 *
 * @author Android Senior Developer
 * @version 1.0
 */
public class ConversorPersonalizado extends ConversorBase {

    /** Base mínima permitida para el algoritmo de dígitos hexadecimales. */
    public static final int BASE_MIN = 2;

    /** Base máxima permitida para el algoritmo de dígitos hexadecimales. */
    public static final int BASE_MAX = 16;

    /** Indica si la base ingresada es válida. */
    private boolean esValida;

    /**
     * Constructor que inicializa el conversor y valida la base.
     *
     * @param numero Número a convertir.
     * @param base   Base destino ingresada por el usuario.
     */
    public ConversorPersonalizado(long numero, int base) {
        super(numero, base);
        this.esValida = validarBase();
    }

    /**
     * Valida si la base actual está dentro del rango [BASE_MIN, BASE_MAX].
     *
     * @return true si la base es válida, false en caso contrario.
     */
    public boolean validarBase() {
        return this.base >= BASE_MIN && this.base <= BASE_MAX;
    }

    /**
     * Realiza la conversión solo si la base es válida.
     * Retorna un mensaje de error si la validación falla.
     *
     * @return Resultado de la conversión o mensaje de error.
     */
    @Override
    public String convertir() {
        if (!esValida) {
            return "Error: Base inválida. Rango permitido: " + BASE_MIN + " - " + BASE_MAX;
        }
        return algoritmoConversion(this.numero, this.base);
    }

    /**
     * Descripción específica para conversiones personalizadas.
     *
     * @return Cadena indicando conversión a base personalizada.
     */
    @Override
    public String obtenerDescripcion() {
        return "Conversión a Base " + this.base + " (Personalizada)";
    }
}