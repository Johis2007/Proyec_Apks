package com.example.conversionnumerica;

/**
 * Clase abstracta base para la jerarquía de conversores numéricos.
 * Define la estructura general y el algoritmo de conversión por divisiones sucesivas.
 *
 * @author Android Senior Developer
 * @version 1.0
 */
public abstract class ConversorBase {

    /** Número entero largo a convertir. */
    protected long numero;

    /** Base numérica destino. */
    protected int base;

    /**
     * Constructor de la clase base.
     *
     * @param numero El número decimal a convertir.
     * @param base   La base destino para la conversión.
     */
    protected ConversorBase(long numero, int base) {
        this.numero = numero;
        this.base = base;
    }

    /**
     * Método abstracto que obliga a las subclases a implementar la lógica específica de conversión.
     *
     * @return Cadena de texto con el resultado de la conversión.
     */
    public abstract String convertir();

    /**
     * Algoritmo de conversión genérico mediante divisiones sucesivas.
     * Soporta números negativos y bases hasta 16 (dígitos 0-9, A-F).
     *
     * @param num  El valor absoluto del número a convertir.
     * @param base La base destino.
     * @return Cadena representando el número en la base destino.
     */
    protected String algoritmoConversion(long num, int base) {
        if (num == 0) {
            return "0";
        }

        StringBuilder resultado = new StringBuilder();
        // Caracteres para representar dígitos mayores a 9
        char[] digitos = "0123456789ABCDEF".toCharArray();

        long n = Math.abs(num);

        while (n > 0) {
            int residuo = (int) (n % base);
            resultado.insert(0, digitos[residuo]);
            n = n / base;
        }

        // Manejo de signo negativo
        if (num < 0) {
            resultado.insert(0, "-");
        }

        return resultado.toString();
    }

    /**
     * Método sobreescribible para obtener una descripción de la conversión realizada.
     *
     * @return Cadena descriptiva por defecto.
     */
    public String obtenerDescripcion() {
        return "Conversión a base " + base;
    }
}
