package com.example.capitalizacionapp;


/**
 * Servicio que contiene toda la lógica de negocio.
 * MainActivity solo llama calcular() y recibe ResultadoCalculo;
 * no conoce ninguna fórmula financiera.
 *
 * <p>Aquí ocurre el polimorfismo: la variable {@code cap} es de tipo
 * {@link Capitalizacion} (abstracto) y apunta a la subclase concreta.</p>
 *
 * @author  Docente de Programación Orientada a Objetos
 * @version 1.0
 */
public class CalculadoraCapitalizacion {

    public static final int TIPO_SIMPLE    = 0;
    public static final int TIPO_COMPUESTA = 1;

    /**
     * Realiza el cálculo según el tipo elegido.
     *
     * @param tipo    {@link #TIPO_SIMPLE} o {@link #TIPO_COMPUESTA}.
     * @param capital Capital inicial.
     * @param tasa    Tasa en porcentaje.
     * @param tiempo  Tiempo en años.
     * @return {@link ResultadoCalculo} con todos los datos.
     */
    public ResultadoCalculo calcular(int tipo, double capital, double tasa, double tiempo) {

        // Variable polimórfica: tipo padre → subclase concreta
        Capitalizacion cap;

        switch (tipo) {
            case TIPO_SIMPLE:
                cap = new CapitalizacionSimple(capital, tasa, tiempo);
                break;
            case TIPO_COMPUESTA:
                cap = new CapitalizacionCompuesta(capital, tasa, tiempo);
                break;
            default:
                throw new IllegalArgumentException("Tipo desconocido: " + tipo);
        }

        // cap.calcular() ejecuta la versión de la subclase — polimorfismo
        return new ResultadoCalculo(
                cap.getTipoCapitalizacion(),
                capital, tasa, tiempo,
                cap.calcular(),
                cap.calcularInteres()
        );
    }

    /**
     * Valida las entradas del formulario.
     * @return mensaje de error, o null si todo es válido.
     */
    public String validarEntradas(String capitalStr, String tasaStr, String tiempoStr) {
        if (capitalStr == null || capitalStr.trim().isEmpty())
            return "Por favor ingresa el capital inicial.";
        if (tasaStr == null || tasaStr.trim().isEmpty())
            return "Por favor ingresa la tasa de interés.";
        if (tiempoStr == null || tiempoStr.trim().isEmpty())
            return "Por favor ingresa el tiempo en años.";

        try {
            if (Double.parseDouble(capitalStr) <= 0)
                return "El capital debe ser mayor que cero.";
        } catch (NumberFormatException e) {
            return "El capital debe ser un número válido.";
        }
        try {
            if (Double.parseDouble(tasaStr) <= 0)
                return "La tasa debe ser mayor que cero.";
        } catch (NumberFormatException e) {
            return "La tasa debe ser un número válido.";
        }
        try {
            if (Double.parseDouble(tiempoStr) <= 0)
                return "El tiempo debe ser mayor que cero.";
        } catch (NumberFormatException e) {
            return "El tiempo debe ser un número válido.";
        }

        return null;
    }
}