package com.example.capitalizacionapp;

/**
 * Capitalización Simple: M = C * (1 + i * t)
 *
 * <p>Extiende {@link Capitalizacion} (herencia) y sobreescribe
 * calcular() con la fórmula de interés simple (polimorfismo).</p>
 *
 * @author  Docente de Programación Orientada a Objetos
 * @version 1.0
 */
public class CapitalizacionSimple extends Capitalizacion {

    /** Constructor sin parámetros. */
    public CapitalizacionSimple() {
        super();
    }

    /**
     * Constructor con parámetros.
     * @param capital Capital inicial.
     * @param tasa    Tasa en porcentaje.
     * @param tiempo  Tiempo en años.
     */
    public CapitalizacionSimple(double capital, double tasa, double tiempo) {
        super(capital, tasa, tiempo);
    }

    /**
     * Fórmula: M = C * (1 + i * t)
     * @return monto final con interés simple.
     */
    @Override
    public double calcular() {
        double tasaDecimal = getTasa() / 100.0;
        return getCapital() * (1 + tasaDecimal * getTiempo());
    }

    @Override
    public String getTipoCapitalizacion() {
        return "Capitalización Simple";
    }
}