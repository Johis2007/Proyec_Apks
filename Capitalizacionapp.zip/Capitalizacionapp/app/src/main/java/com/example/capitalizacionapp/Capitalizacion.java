package com.example.capitalizacionapp;


    /**
     * Clase base abstracta que representa el concepto general de Capitalización financiera.
     *
     * <p>Aplica los siguientes principios de POO:</p>
     * <ul>
     *   <li><b>Abstracción:</b> Define la plantilla común para todos los tipos de capitalización.</li>
     *   <li><b>Encapsulamiento:</b> Atributos privados accedidos solo mediante getters/setters.</li>
     *   <li><b>Herencia:</b> Sirve como clase padre para CapitalizacionSimple y variantes futuras.</li>
     *   <li><b>Polimorfismo:</b> El método calcular() es abstracto; cada subclase lo implementa.</li>
     * </ul>
     *
     * @author  Docente de Programación Orientada a Objetos
     * @version 1.0
     */
    public abstract class Capitalizacion {

        // =========================================================
        // ATRIBUTOS PRIVADOS — Encapsulamiento
        // =========================================================
        private double capital;
        private double tasa;
        private double tiempo;

        // =========================================================
        // CONSTRUCTORES — Sobrecarga
        // =========================================================

        /** Constructor sin parámetros. Inicializa atributos en cero. */
        public Capitalizacion() {
            this.capital = 0;
            this.tasa    = 0;
            this.tiempo  = 0;
        }

        /**
         * Constructor con parámetros.
         * @param capital Capital inicial (debe ser mayor que 0).
         * @param tasa    Tasa de interés en porcentaje.
         * @param tiempo  Tiempo en años.
         */
        public Capitalizacion(double capital, double tasa, double tiempo) {
            this.capital = capital;
            this.tasa    = tasa;
            this.tiempo  = tiempo;
        }

        // =========================================================
        // GETTERS Y SETTERS — Encapsulamiento
        // =========================================================

        public double getCapital() { return capital; }

        public void setCapital(double capital) {
            if (capital <= 0) throw new IllegalArgumentException("El capital debe ser mayor que cero.");
            this.capital = capital;
        }

        public double getTasa() { return tasa; }

        public void setTasa(double tasa) {
            if (tasa <= 0) throw new IllegalArgumentException("La tasa debe ser mayor que cero.");
            this.tasa = tasa;
        }

        public double getTiempo() { return tiempo; }

        public void setTiempo(double tiempo) {
            if (tiempo <= 0) throw new IllegalArgumentException("El tiempo debe ser mayor que cero.");
            this.tiempo = tiempo;
        }

        // =========================================================
        // MÉTODOS ABSTRACTOS — Polimorfismo
        // =========================================================

        /** Calcula el monto final. Cada subclase implementa su propia fórmula. */
        public abstract double calcular();

        /** Retorna el nombre descriptivo del tipo de capitalización. */
        public abstract String getTipoCapitalizacion();

        // =========================================================
        // MÉTODO CONCRETO COMPARTIDO
        // =========================================================

        /**
         * Calcula el interés ganado. Usa calcular(), que es polimórfico.
         * @return interés generado durante el período.
         */
        public double calcularInteres() {
            return calcular() - this.capital;
        }

        @Override
        public String toString() {
            return getTipoCapitalizacion()
                    + " | Capital=" + capital
                    + ", Tasa=" + tasa + "%"
                    + ", Tiempo=" + tiempo + " años";
        }
    }
