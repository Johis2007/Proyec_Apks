package com.example.capitalizacionapp;


/**
 * Modelo inmutable que transporta los resultados del cálculo
 * desde la lógica de negocio hacia la interfaz.
 *
 * @author  Docente de Programación Orientada a Objetos
 * @version 1.0
 */
public class ResultadoCalculo {

    private final String tipoCapitalizacion;
    private final double capitalInicial;
    private final double tasa;
    private final double tiempo;
    private final double montoFinal;
    private final double interesGanado;

    /**
     * Constructor completo. Atributos final: el resultado no se modifica.
     */
    public ResultadoCalculo(String tipoCapitalizacion, double capitalInicial,
                            double tasa, double tiempo,
                            double montoFinal, double interesGanado) {
        this.tipoCapitalizacion = tipoCapitalizacion;
        this.capitalInicial     = capitalInicial;
        this.tasa               = tasa;
        this.tiempo             = tiempo;
        this.montoFinal         = montoFinal;
        this.interesGanado      = interesGanado;
    }

    public String getTipoCapitalizacion() { return tipoCapitalizacion; }
    public double getCapitalInicial()     { return capitalInicial; }
    public double getTasa()               { return tasa; }
    public double getTiempo()             { return tiempo; }
    public double getMontoFinal()         { return montoFinal; }
    public double getInteresGanado()      { return interesGanado; }
}
