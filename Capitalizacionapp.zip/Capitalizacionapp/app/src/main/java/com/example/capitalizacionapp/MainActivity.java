package com.example.capitalizacionapp;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Activity principal. Responsabilidad única: manejar la UI.
 * Ninguna fórmula financiera vive aquí; todo se delega a
 * {@link CalculadoraCapitalizacion}.
 *
 * @author  Docente de Programación Orientada a Objetos
 * @version 1.0
 */
public class MainActivity extends AppCompatActivity {

    // Vistas
    private EditText etCapital, etTasa, etTiempo;
    private RadioGroup rgTipoCapitalizacion;
    private Button btnCalcular, btnLimpiar;
    private LinearLayout layoutResultados;
    private TextView tvTipoResultado, tvCapitalResultado, tvTasaResultado;
    private TextView tvTiempoResultado, tvMontoResultado, tvInteresResultado;

    // Objeto de negocio
    private CalculadoraCapitalizacion calculadora;
    private NumberFormat formatoMoneda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calculadora   = new CalculadoraCapitalizacion();
        formatoMoneda = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));

        inicializarVistas();
        configurarListeners();
    }

    private void inicializarVistas() {
        etCapital            = findViewById(R.id.etCapital);
        etTasa               = findViewById(R.id.etTasa);
        etTiempo             = findViewById(R.id.etTiempo);
        rgTipoCapitalizacion = findViewById(R.id.rgTipoCapitalizacion);
        btnCalcular          = findViewById(R.id.btnCalcular);
        btnLimpiar           = findViewById(R.id.btnLimpiar);
        layoutResultados     = findViewById(R.id.layoutResultados);
        tvTipoResultado      = findViewById(R.id.tvTipoResultado);
        tvCapitalResultado   = findViewById(R.id.tvCapitalResultado);
        tvTasaResultado      = findViewById(R.id.tvTasaResultado);
        tvTiempoResultado    = findViewById(R.id.tvTiempoResultado);
        tvMontoResultado     = findViewById(R.id.tvMontoResultado);
        tvInteresResultado   = findViewById(R.id.tvInteresResultado);
    }

    private void configurarListeners() {
        btnCalcular.setOnClickListener(v -> ejecutarCalculo());
        btnLimpiar.setOnClickListener(v  -> limpiarFormulario());
    }

    /**
     * Orquesta el proceso: leer → validar → calcular → mostrar.
     */
    private void ejecutarCalculo() {
        String capitalStr = etCapital.getText().toString().trim();
        String tasaStr    = etTasa.getText().toString().trim();
        String tiempoStr  = etTiempo.getText().toString().trim();

        String error = calculadora.validarEntradas(capitalStr, tasaStr, tiempoStr);
        if (error != null) {
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
            return;
        }

        double capital = Double.parseDouble(capitalStr);
        double tasa    = Double.parseDouble(tasaStr);
        double tiempo  = Double.parseDouble(tiempoStr);

        int tipo = (rgTipoCapitalizacion.getCheckedRadioButtonId() == R.id.rbSimple)
                ? CalculadoraCapitalizacion.TIPO_SIMPLE
                : CalculadoraCapitalizacion.TIPO_COMPUESTA;

        // Polimorfismo ocurre dentro de calcular()
        ResultadoCalculo resultado = calculadora.calcular(tipo, capital, tasa, tiempo);
        mostrarResultados(resultado);
    }

    private void mostrarResultados(ResultadoCalculo resultado) {
        tvTipoResultado.setText(resultado.getTipoCapitalizacion());
        tvCapitalResultado.setText(formatoMoneda.format(resultado.getCapitalInicial()));
        tvTasaResultado.setText(String.format(Locale.getDefault(), "%.2f %%", resultado.getTasa()));
        tvTiempoResultado.setText(String.format(Locale.getDefault(), "%.1f año(s)", resultado.getTiempo()));
        tvMontoResultado.setText(formatoMoneda.format(resultado.getMontoFinal()));
        tvInteresResultado.setText(formatoMoneda.format(resultado.getInteresGanado()));

        if (layoutResultados.getVisibility() == View.GONE) {
            layoutResultados.setVisibility(View.VISIBLE);
            animarAparicion(layoutResultados);
        }
    }

    private void animarAparicion(View vista) {
        vista.setAlpha(0f);
        vista.setTranslationY(40f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(
                ObjectAnimator.ofFloat(vista, "alpha", 0f, 1f),
                ObjectAnimator.ofFloat(vista, "translationY", 40f, 0f)
        );
        set.setDuration(400);
        set.start();
    }

    private void limpiarFormulario() {
        etCapital.setText("");
        etTasa.setText("");
        etTiempo.setText("");
        rgTipoCapitalizacion.check(R.id.rbSimple);
        layoutResultados.setVisibility(View.GONE);
        etCapital.requestFocus();
    }
}