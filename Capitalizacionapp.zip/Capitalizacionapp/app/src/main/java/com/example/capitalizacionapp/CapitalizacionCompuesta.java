package com.example.capitalizacionapp;


/**
 * Capitalización Compuesta: M = C * (1 + i)^t
 *
 * <p>Demuestra polimorfismo real: misma referencia {@link Capitalizacion},
 * comportamiento diferente en calcular().</p>
 *
 * @author  Docente de Programación Orientada a Objetos
 * @version 1.0
 */
public class CapitalizacionCompuesta extends Capitalizacion {

    /** Constructor sin parámetros. */
    public CapitalizacionCompuesta() {
        super();
    }

    /**
     * Constructor con parámetros.
     * @param capital Capital inicial.
     * @param tasa    Tasa en porcentaje.
     * @param tiempo  Tiempo en años.
     */
    public CapitalizacionCompuesta(double capital, double tasa, double tiempo) {
        super(capital, tasa, tiempo);
    }

    /**
     * Fórmula: M = C * (1 + i)^t
     * @return monto final con interés compuesto.
     */
    @Override
    public double calcular() {
        double tasaDecimal = getTasa() / 100.0;
        return getCapital() * Math.pow(1 + tasaDecimal, getTiempo());
    }

    @Override
    public String getTipoCapitalizacion() {
        return "Capitalización Compuesta";
    }
}
